{{/*
Expand the name of the chart.
*/}}
{{- define "kubenest-operator.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "kubenest-operator.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "kubenest-operator.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "kubenest-operator.labels" -}}
helm.sh/chart: {{ include "kubenest-operator.chart" . }}
{{ include "kubenest-operator.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: kubenest-operator
{{- end }}

{{/*
Selector labels
*/}}
{{- define "kubenest-operator.selectorLabels" -}}
app.kubernetes.io/name: {{ include "kubenest-operator.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "kubenest-operator.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "kubenest-operator.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Create the name of the cluster role to use
*/}}
{{- define "kubenest-operator.clusterRoleName" -}}
{{- printf "%s-manager-role" (include "kubenest-operator.fullname" .) }}
{{- end }}

{{/*
Create the name of the cluster role binding to use
*/}}
{{- define "kubenest-operator.clusterRoleBindingName" -}}
{{- printf "%s-manager-rolebinding" (include "kubenest-operator.fullname" .) }}
{{- end }}

{{/*
Create the name of the leader election role to use
*/}}
{{- define "kubenest-operator.leaderElectionRoleName" -}}
{{- printf "%s-leader-election-role" (include "kubenest-operator.fullname" .) }}
{{- end }}

{{/*
Create the name of the leader election role binding to use
*/}}
{{- define "kubenest-operator.leaderElectionRoleBindingName" -}}
{{- printf "%s-leader-election-rolebinding" (include "kubenest-operator.fullname" .) }}
{{- end }}

{{/*
Create the name of the metrics service to use
*/}}
{{- define "kubenest-operator.metricsServiceName" -}}
{{- printf "%s-controller-manager-metrics-service" (include "kubenest-operator.fullname" .) }}
{{- end }}

{{/*
Create the name of the webhook service to use
*/}}
{{- define "kubenest-operator.webhookServiceName" -}}
{{- printf "%s-webhook-service" (include "kubenest-operator.fullname" .) }}
{{- end }}

{{/*
Create the name of the webhook configuration to use
*/}}
{{- define "kubenest-operator.webhookConfigurationName" -}}
{{- printf "%s-validating-webhook-configuration" (include "kubenest-operator.fullname" .) }}
{{- end }}

{{/*
Create the name of the manager config ConfigMap to use
*/}}
{{- define "kubenest-operator.managerConfigName" -}}
{{- printf "%s-manager-config" (include "kubenest-operator.fullname" .) }}
{{- end }}

{{/*
Create the name of the webhook certificates secret to use
*/}}
{{- define "kubenest-operator.webhookCertsSecretName" -}}
{{- printf "%s-webhook-certs" (include "kubenest-operator.fullname" .) }}
{{- end }}

{{/*
Create the webhook service FQDN
*/}}
{{- define "kubenest-operator.webhookServiceFQDN" -}}
{{- printf "%s.%s.svc" (include "kubenest-operator.webhookServiceName" .) .Release.Namespace }}
{{- end }}

{{/*
Validate required values
*/}}
{{- define "kubenest-operator.validateValues" -}}
{{- if not .Values.kubenest.jwtSecret }}
{{- fail "kubenest.jwtSecret is required" }}
{{- end }}
{{- if not .Values.kubenest.clusterID }}
{{- fail "kubenest.clusterID is required" }}
{{- end }}
{{- end }}

{{/*
Image pull secrets
*/}}
{{- define "kubenest-operator.imagePullSecrets" -}}
{{- $pullSecrets := list }}
{{- if .Values.global.imagePullSecrets }}
{{- $pullSecrets = concat $pullSecrets .Values.global.imagePullSecrets }}
{{- end }}
{{- if .Values.imagePullSecrets }}
{{- $pullSecrets = concat $pullSecrets .Values.imagePullSecrets }}
{{- end }}
{{- if $pullSecrets }}
imagePullSecrets:
{{- range $pullSecrets }}
- name: {{ . }}
{{- end }}
{{- end }}
{{- end }}
