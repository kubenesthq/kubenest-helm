# Kubenest Operator Helm Chart

This Helm chart deploys the Kubenest Operator v2 to a Kubernetes cluster.

## Prerequisites

- Kubernetes 1.27+
- Helm 3.8+
- kubectl configured to access your cluster

## CRD Installation

This chart includes Custom Resource Definitions (CRDs) in the `crds/` directory. Helm will automatically install these CRDs during chart installation.

**Important Notes:**
- CRDs are installed before other chart resources
- CRDs are **not** automatically removed when the chart is uninstalled (Helm 3 behavior)
- To skip CRD installation, use: `helm install --skip-crds`
- To upgrade CRDs, you must manually apply them or reinstall the chart

The following CRDs are included:
- `projects.apps.kubenest.io`
- `workloads.apps.kubenest.io`
- `addons.apps.kubenest.io`
- `buildrequests.apps.kubenest.io`
- `stackdeploys.apps.kubenest.io`

## Installation

### Add Helm Repository

```bash
helm repo add kubenest https://charts.kubenest.io
helm repo update
```

### Install the Chart

```bash
helm install kubenest-operator-2 kubenest/kubenest-operator-2 \
  --namespace kubenest-system \
  --create-namespace \
  --set kubenest.jwtSecret="your-jwt-secret" \
  --set kubenest.clusterID="your-cluster-id"
```

### Install from Source

```bash
git clone https://github.com/kubenesthq/operator-v2.git
cd operator-v2
helm install kubenest-operator-2 charts/kubenest-operator \
  --namespace kubenest-system \
  --create-namespace \
  --set kubenest.jwtSecret="your-jwt-secret" \
  --set kubenest.clusterID="your-cluster-id"
```

## Configuration

The following table lists the configurable parameters and their default values.

### Image Configuration

| Parameter | Description | Default |
|-----------|-------------|---------|
| `image.repository` | Operator image repository | `ghcr.io/kubenesthq/operatorv2` |
| `image.tag` | Operator image tag | `v2.0.0` |
| `image.pullPolicy` | Image pull policy | `IfNotPresent` |
| `imagePullSecrets` | Image pull secrets | `[]` |

### Deployment Configuration

| Parameter | Description | Default |
|-----------|-------------|---------|
| `replicaCount` | Number of operator replicas | `1` |
| `podAnnotations` | Pod annotations | `{}` |
| `podSecurityContext` | Pod security context | See values.yaml |
| `securityContext` | Container security context | See values.yaml |
| `resources` | Resource limits and requests | See values.yaml |
| `nodeSelector` | Node selector | `{}` |
| `tolerations` | Tolerations | `[]` |
| `affinity` | Affinity rules | `{}` |

### Kubenest Configuration

| Parameter | Description | Default |
|-----------|-------------|---------|
| `kubenest.backendURL` | Backend WebSocket URL | `wss://api.kubenest.io/v2/operator/events` |
| `kubenest.jwtSecret` | JWT secret for authentication | `""` (required) |
| `kubenest.clusterID` | Unique cluster identifier | `""` (required) |
| `kubenest.logLevel` | Log level | `info` |
| `kubenest.defaultChartRepo` | Default chart repository for kubenest-workload chart | `https://docs.kubenest.io` |
| `kubenest.reconnectInterval` | WebSocket reconnect interval | `30s` |
| `kubenest.maxReconnectAttempts` | Max reconnection attempts | `10` |
| `kubenest.buildJobTimeout` | Build job timeout | `30m` |
| `kubenest.defaultBuilderImage` | Default buildpack builder | `paketobuildpacks/builder:base` |
| `kubenest.defaultKanikoImage` | Default Kaniko image | `gcr.io/kaniko-project/executor:latest` |

### RBAC Configuration

| Parameter | Description | Default |
|-----------|-------------|---------|
| `rbac.create` | Create RBAC resources | `true` |
| `serviceAccount.create` | Create service account | `true` |
| `serviceAccount.name` | Service account name | `""` |
| `serviceAccount.annotations` | Service account annotations | `{}` |

### Monitoring Configuration

| Parameter | Description | Default |
|-----------|-------------|---------|
| `controllerManager.metrics.service.enabled` | Enable metrics service | `true` |
| `prometheusRule.enabled` | Create PrometheusRule for alerting | `false` |

### Webhook Configuration

| Parameter | Description | Default |
|-----------|-------------|---------|
| `controllerManager.webhook.enabled` | Enable admission webhooks | `false` |
| `controllerManager.webhook.port` | Webhook server port | `9443` |
| `webhookCertificates.generate` | Generate webhook certificates | `true` |

## Examples

### Basic Installation

```bash
helm install kubenest-operator-2 kubenest/kubenest-operator-2 \
  --namespace kubenest-system \
  --create-namespace \
  --set kubenest.jwtSecret="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..." \
  --set kubenest.clusterID="production-cluster-001"
```

### Production Installation with Custom Values

Create a `values.yaml` file:

```yaml
image:
  repository: ghcr.io/kubenesthq/operatorv2
  tag: v2.0.0
  pullPolicy: Always

replicaCount: 2

resources:
  limits:
    cpu: 1000m
    memory: 1Gi
  requests:
    cpu: 200m
    memory: 256Mi

kubenest:
  backendURL: "wss://your-backend.example.com/v2/operator/events"
  jwtSecret: "your-production-jwt-secret"
  clusterID: "production-cluster-001"
  logLevel: "info"
  defaultChartRepo: "https://docs.kubenest.io/charts"

prometheusRule:
  enabled: true

controllerManager:
  webhook:
    enabled: true

nodeSelector:
  kubernetes.io/os: linux

tolerations:
- key: "node-role.kubernetes.io/control-plane"
  operator: "Exists"
  effect: "NoSchedule"

affinity:
  podAntiAffinity:
    preferredDuringSchedulingIgnoredDuringExecution:
    - weight: 100
      podAffinityTerm:
        labelSelector:
          matchExpressions:
          - key: app.kubernetes.io/name
            operator: In
            values:
            - kubenest-operator
        topologyKey: kubernetes.io/hostname
```

Install with custom values:

```bash
helm install kubenest-operator-2 kubenest/kubenest-operator-2 \
  --namespace kubenest-system \
  --create-namespace \
  --values values.yaml
```

### Development Installation

```bash
helm install kubenest-operator-2 kubenest/kubenest-operator-2 \
  --namespace kubenest-system \
  --create-namespace \
  --set kubenest.jwtSecret="dev-jwt-secret" \
  --set kubenest.clusterID="dev-cluster" \
  --set kubenest.logLevel="debug" \
  --set image.pullPolicy="Always" \
  --set resources.limits.cpu="200m" \
  --set resources.limits.memory="256Mi"
```

## Upgrading

### Upgrade to New Version

```bash
helm repo update
helm upgrade kubenest-operator-2 kubenest/kubenest-operator-2 \
  --namespace kubenest-system \
  --reuse-values
```

### Upgrade with New Values

```bash
helm upgrade kubenest-operator-2 kubenest/kubenest-operator-2 \
  --namespace kubenest-system \
  --values new-values.yaml
```

## Uninstalling

```bash
helm uninstall kubenest-operator-2 --namespace kubenest-system
```

To also remove CRDs (this will delete all Kubenest resources):

```bash
kubectl delete crd projects.apps.kubenest.io
kubectl delete crd workloads.apps.kubenest.io
kubectl delete crd addons.apps.kubenest.io
kubectl delete crd buildrequests.apps.kubenest.io
kubectl delete crd stackdeploys.apps.kubenest.io
```

## Troubleshooting

### Check Installation Status

```bash
helm status kubenest-operator-2 -n kubenest-system
kubectl get all -n kubenest-system
```

### View Operator Logs

```bash
kubectl logs -n kubenest-system deployment/kubenest-operator-2-controller-manager -f
```

### Check CRDs

```bash
kubectl get crd | grep kubenest.io
```

### Validate Configuration

```bash
helm get values kubenest-operator-2 -n kubenest-system
```

## Security Considerations

- Always use strong, unique JWT secrets
- Enable RBAC and use least privilege principles
- Consider enabling admission webhooks for validation
- Use image pull secrets for private registries
- Implement network policies for traffic control
- Enable Pod Security Standards

## Support

- **Documentation**: https://docs.kubenest.io
- **GitHub**: https://github.com/kubenesthq/operator-v2
- **Issues**: https://github.com/kubenesthq/operator-v2/issues
- **Support**: support@kubenest.io
